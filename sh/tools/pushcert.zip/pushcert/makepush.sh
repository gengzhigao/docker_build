#!/bin/sh
password=$1
openssl x509 -inform der -in mdm.cer -out mdm.pem
openssl x509 -inform der -in AppleWWDRCA.cer -out intermediate.pem
openssl x509 -inform der -in AppleIncRootCertificate.cer -out root.pem
openssl genrsa -des3 -passout pass:${password}  -out customerPrivateKey.pem 2048
openssl req -new -key customerPrivateKey.pem -out customer.csr -passin pass:${password} -subj /C=CN/ST=Beijing/L=Beijing/O=3G2WIN/OU=AppCan/CN=mdmpush
openssl req -inform pem -outform der -in customer.csr -out customer.der
